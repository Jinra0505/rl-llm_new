# V3b process summary verification

All corrected seed-level summaries use true unique seed counts. The maximum seed-level `n_seeds` is <= 3. Trace-level summaries use `n_traces` instead of `n_seeds`.

{
  "experiments_rerun": false,
  "model_code_changed": false,
  "seed_level_n_seeds_max_cumulative": 3,
  "seed_level_n_seeds_max_stepwise": 3,
  "seed_level_n_seeds_max_action": 3,
  "seed_level_n_seeds_max_stage": 3,
  "trace_level_uses_n_traces": true,
  "cumulative_seed_level_rows": 120,
  "stepwise_seed_level_rows": 120,
  "action_seed_level_rows": 21,
  "stage_seed_level_rows": 6,
  "action_seed_level_share_sum_by_method": {
    "standard_moderate|baseline_rl": 0.9999999999999992,
    "standard_moderate|full_outer_loop": 0.9999999999999993,
    "standard_moderate|single_shot_llm": 0.9999999999999994
  },
  "stage_seed_level_share_sum_by_method": {
    "standard_moderate|baseline_rl": 1.0,
    "standard_moderate|full_outer_loop": 1.0,
    "standard_moderate|single_shot_llm": 1.0
  },
  "recommended_for_paper_plotting": [
    "standard_moderate_mean_cumulative_progress_seed_level.csv",
    "standard_moderate_mean_stepwise_progress_seed_level.csv",
    "standard_moderate_action_category_share_seed_level.csv",
    "standard_moderate_stage_share_seed_level.csv",
    "standard_moderate_zone_layer_recovery_seed_level.csv",
    "figure_ready_metrics.csv",
    "robustness_stress_summary.csv"
  ]
}