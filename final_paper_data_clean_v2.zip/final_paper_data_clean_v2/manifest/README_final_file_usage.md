# Final Paper Data Clean Package

This package contains only the files recommended for final paper plotting and result writing.

## 1. final_tables_v3/

Use these files for final performance, main case, robustness, and per-seed figures:

- `standard_moderate_summary.csv`
- `standard_moderate_per_seed.csv`
- `resource_moderate_summary.csv`
- `resource_moderate_per_seed.csv`
- `standard_severe_summary.csv`
- `standard_severe_per_seed.csv`
- `figure_ready_metrics.csv`
- `robustness_stress_summary.csv`
- `robustness_key_metrics_long.csv`

Recommended uses:
- main standard-moderate metric comparison;
- resource-moderate robustness comparison;
- standard-severe robustness comparison;
- cross-scenario heatmap / dot plot;
- per-seed distribution figures.

Important:
- `resource_moderate / ablation_fixed_global` has limited evidence (`partial_n1`) and should not be used as a strong main-text comparison.
- Do not claim `full_outer_loop` is best on every metric. The stronger narrative is recovery floor, safety capacity, robustness, and structured process behavior.

## 2. process_summaries_v3b/

Use these corrected V3b seed-level files for process and mechanism plots:

- `standard_moderate_mean_cumulative_progress_seed_level.csv`
- `standard_moderate_mean_stepwise_progress_seed_level.csv`
- `standard_moderate_action_category_share_seed_level.csv`
- `standard_moderate_stage_share_seed_level.csv`
- `standard_moderate_zone_layer_recovery_seed_level.csv` if present.

These replace the older ambiguous process summaries where `n_seeds` was actually counting traces/episodes.

Recommended uses:
- cumulative recovery progress curve;
- stepwise progress curve;
- action category composition;
- stage composition;
- zone-layer recovery structure.

## 3. diagnostics_keep/

These files are retained for verification and method/data provenance. They are not primary plotting inputs.

Most important diagnostics:
- `v3_final_verification_report.*`
- `v3_targeted_rerun_report.*`
- `v3_process_metadata_diagnosis.*`
- `v3_duplicate_result_diagnosis.*`
- `v3b_process_summary_verification.md`

## 4. Files intentionally excluded

The following are intentionally not included for final plotting:
- v1 result folders;
- v2 result folders;
- old individual JSON runs;
- old `summary.json`;
- old process summaries without `seed_level` suffix;
- raw per-step traces unless needed for a separate audit.

## Recommended final plotting rule

Use:

- V3 `final_tables_v3/` for final performance and robustness figures.
- V3b `process_summaries_v3b/` for process and mechanism figures.
- `diagnostics_keep/` only for provenance and explanation.



## v2 update

This v2 package explicitly includes:
- `process_summaries_v3b/process_file_inventory_v3b.csv`
- verified V3b seed-level action category share file
- verified V3b seed-level stage share file

The action and stage seed-level files match the uploaded V3b corrected files. The process inventory file was missing from the previous zip and is now included.
